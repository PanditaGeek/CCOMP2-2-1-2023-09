#include <iostream>
using namespace std;

bool esPar(int n){
  return (n % 2 == 0);
}

long long SumaParesFibonacci(int max){
  int x1 = 0, x2 = 1, f3=0;
  long long suma = 0;

  while (f3 < max) {
    if (esPar(f3)){
      suma += f3;
    }
      f3 = x1 + x2;
      x1 = x2;
      x2 = f3;
  }

  return suma;
}

int main() {
  long long fibonacciPares = SumaParesFibonacci(4000000);
  cout << fibonacciPares << endl;
  return 0;
}