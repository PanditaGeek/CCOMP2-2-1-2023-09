#include <iostream>
using namespace std;

bool Primo(int numero) {
  for (int i = 2; i < numero/2; i++) {
        if (numero % i == 0) {
            return false;
        }
    }
    return true;
}

int main() {
  int fpmayor = 0;
  int factores; 
  long long n = 600851475143;
  for(long long i = 2; i < n; i++){
    while((n % i == 0)){
      if(Primo(i)){
        n = n/i;
      } 
      else {
        break;;
      }
    factores = i;
    }
  }
  cout << factores << endl;
  return 0;
}