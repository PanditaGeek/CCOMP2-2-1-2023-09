#include <iostream>
using namespace std;

bool Palindromo(int n){
  string str = to_string(n);
  int i = 0, j = str.length() - 1;
  while(i < j){
    if(str[i] != str[j]){
      return false;
    }
    i++;
    j--;
  }
  return true;
}

int main() {
  int max = 0;
  for(int i = 100; i < 1000; i++){
    for(int j = 100; j < 1000; j++){
      int mult = i * j;
      if(Palindromo(mult) && mult > max){
        max = mult;
        ///cout << i << j << endl;///
      }
    }
  }
  cout << max << endl;
  return 0;
}