#include <iostream>
using namespace std;

int main(){

  long long suma1 = 0, suma2 = 0, suma3 = 0, suma4 = 0, resta = 0;
  
  for(long long i = 1; i <= 100; i++){
    suma1 = i*i;
    suma2 += suma1;
  }

  for(long long i = 1; i <= 100; i++){
    suma3 += i;
    suma4 = suma3 * suma3;
  }

  ///cout << suma2 << endl;///
  ///cout << suma4 << endl;/// 
  cout << (suma4 - suma2) << endl; 
  return 0;
}